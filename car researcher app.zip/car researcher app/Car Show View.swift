//
//  Car Show View.swift
//  car researcher app
//
//  Created by admin on 5/13/22.

// takes output from SelectorView, runs through Calculator View, and outputs image from here.

import SwiftUI


//struct EntireCars {
//    var carOutputs = CarOutputs
//    var transInput = ?
//    var powerInput
//    var driveTrainInput
//    var sizeInput
//    var doorsInput
//
//}

struct Car_Show_View: View {
    var body: some View {
        List {
        
            Text("Have Some Cars Plz")
        }
        
        
      
    }
}

struct Car_Show_View_Previews: PreviewProvider {
    static var previews: some View {
        Car_Show_View()
    }
}
